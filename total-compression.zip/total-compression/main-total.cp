#include <ilcplex/ilocplex.h>
#include <vector>
#include <iostream>
#include <fstream>
#include <sstream>
#include <numeric>
#include <cmath>
#include <algorithm>
#include <ctime>
#include <iomanip>
#include <random>
#include <string>
#include <limits>
#include <cstdlib>
#include <chrono>

ILOSTLBEGIN

using namespace std;

/*
 * Sensitivity analysis code for the total-compression RIPMSP.
 *
 * Main additions relative to the previous total-compression code:
 * 1. Processing-time heterogeneity factor:
 *      PT-N: p_j ~ U[10,24]
 *      PT-W: p_j ~ U[1,100]
 * 2. Machine-load/tightness factor:
 *      rho in {1.05, 1.15, 1.25}, where rho = sum_j p_j / (m C*)
 *      C*(rho) = ceil(sum_j p_j / (m rho)).
 * 3. Both continuous and discrete adjusted processing-time domains are tested.
 * 4. Results are written to:
 *      /Users/shijinwang/Desktop/sensitivityanalysis/experiment_TIMESTAMP
 *
 * Compatibility notes:
 * - Avoids std::filesystem for CPLEX 12.7 / Xcode 14.2 compatibility.
 * - Uses C++14-compatible constructs.
 */

// ----------------------------- Global settings -----------------------------

static const double EPS = 1e-6;
static const double MASTER_TIME_LIMIT_SEC = 900.0;
static const double SUBPROBLEM_TIME_LIMIT_SEC = 900.0;
static const double MIP_TIME_LIMIT_SEC = 900.0;
static const int MAX_BD_ITERATIONS = 1000;
static const int NUM_RUNS_PER_COMBINATION = 10;

// Domain of adjusted processing times \tilde{p}_j.
// CONTINUOUS: \tilde{p}_j can be fractional.
// DISCRETE:   \tilde{p}_j is integer-valued.
static const char* PTILDE_CONTINUOUS = "CONTINUOUS";
static const char* PTILDE_DISCRETE   = "DISCRETE";

bool isDiscretePtildeMode(const string& mode) {
    return mode == PTILDE_DISCRETE;
}

string shortPtildeMode(const string& mode) {
    return isDiscretePtildeMode(mode) ? "DISC" : "CONT";
}

// If the rho-generated C* is below the minimum feasible makespan under full
// compression, the code sets C* to the minimum feasible value and records this
// adjustment. This prevents infeasible sensitivity instances from stopping the
// whole experiment, especially under rho=1.25.
static const bool ADJUST_INFEASIBLE_CSTAR_TO_MIN_FEASIBLE = true;

// ----------------------------- Utility functions -----------------------------

string getCurrentTimestamp() {
    time_t now = time(NULL);
    tm* local_time = localtime(&now);
    char buffer[64];
    strftime(buffer, sizeof(buffer), "%Y%m%d_%H%M%S", local_time);
    return string(buffer);
}

string sanitizeRho(double rho) {
    stringstream ss;
    ss << fixed << setprecision(2) << rho;
    string s = ss.str();
    replace(s.begin(), s.end(), '.', 'p');
    return s;
}

void makeDirectory(const string& dir) {
    string cmd = "mkdir -p \"" + dir + "\"";
    int ret = system(cmd.c_str());
    if (ret != 0) {
        cerr << "Warning: could not create directory: " << dir << endl;
    }
}

template<typename T>
double meanValue(const vector<T>& values) {
    if (values.empty()) return 0.0;
    double s = 0.0;
    for (size_t i = 0; i < values.size(); ++i) s += static_cast<double>(values[i]);
    return s / static_cast<double>(values.size());
}

template<typename T>
double stdValue(const vector<T>& values) {
    if (values.size() <= 1) return 0.0;
    double m = meanValue(values);
    double v = 0.0;
    for (size_t i = 0; i < values.size(); ++i) {
        double d = static_cast<double>(values[i]) - m;
        v += d * d;
    }
    v /= static_cast<double>(values.size());
    return sqrt(v);
}

int ceilDivInt(int a, int b) {
    return (a + b - 1) / b;
}

string cplexStatusToString(IloAlgorithm::Status st) {
    switch (st) {
        case IloAlgorithm::Optimal: return "Optimal";
        case IloAlgorithm::Feasible: return "Feasible";
        case IloAlgorithm::Infeasible: return "Infeasible";
        case IloAlgorithm::Unbounded: return "Unbounded";
        case IloAlgorithm::InfeasibleOrUnbounded: return "InfeasibleOrUnbounded";
        case IloAlgorithm::Unknown: return "Unknown";
        case IloAlgorithm::Error: return "Error";
        default: return "Other";
    }
}

// ----------------------------- Data structures -----------------------------

struct InstanceData {
    string pt_class;
    int n;
    int m;
    int run_id;
    unsigned int seed;
    double target_rho;
    double actual_rho;

    vector<int> p;
    vector<int> delta;

    int sum_p;
    int sum_delta;
    int sum_min_p;
    int max_min_p;
    int min_possible_makespan;
    int cstar_raw;
    int C_star;
    bool cstar_adjusted;
};

struct MethodResult {
    bool feasible;
    bool solved;
    bool optimal;
    bool time_limit;
    string status;

    double objective;
    double best_bound;
    double gap;
    double time_sec;
    int iterations;

    MethodResult()
        : feasible(false), solved(false), optimal(false), time_limit(false), status("NotRun"),
          objective(numeric_limits<double>::quiet_NaN()),
          best_bound(numeric_limits<double>::quiet_NaN()),
          gap(numeric_limits<double>::quiet_NaN()), time_sec(0.0), iterations(0) {}
};

struct RunResult {
    InstanceData inst;
    string ptilde_mode;
    MethodResult bd;
    MethodResult mip;
    double abs_obj_diff;
    double bd_norm_obj;
    double mip_norm_obj;
};

// ----------------------------- Instance generation -----------------------------

InstanceData generateSensitivityInstance(int n, int m, const string& pt_class,
                                         double target_rho, int run_id) {
    InstanceData inst;
    inst.pt_class = pt_class;
    inst.n = n;
    inst.m = m;
    inst.run_id = run_id;
    inst.target_rho = target_rho;

    int pt_code = (pt_class == "PT-W") ? 2 : 1;
    int rho_code = static_cast<int>(round(target_rho * 100.0));
    inst.seed = 20260429u + static_cast<unsigned int>(1000003 * run_id)
                + static_cast<unsigned int>(10007 * n)
                + static_cast<unsigned int>(1009 * m)
                + static_cast<unsigned int>(101 * pt_code)
                + static_cast<unsigned int>(17 * rho_code);

    mt19937 rng(inst.seed);
    inst.p.assign(n, 0);
    inst.delta.assign(n, 0);

    if (pt_class == "PT-N") {
        // Narrow processing-time class, consistent with the original baseline range.
        uniform_int_distribution<int> p_dist(10, 24);
        uniform_int_distribution<int> d_dist(1, 5);
        for (int j = 0; j < n; ++j) {
            inst.p[j] = p_dist(rng);
            inst.delta[j] = d_dist(rng);
            inst.delta[j] = min(inst.delta[j], max(0, inst.p[j] - 1));
        }
    } else {
        // Wide processing-time class requested in the sensitivity analysis.
        // Compression limits are proportional to p_j to avoid making large jobs
        // artificially almost incompressible.
        uniform_int_distribution<int> p_dist(1, 100);
        uniform_real_distribution<double> r_dist(0.10, 0.30);
        for (int j = 0; j < n; ++j) {
            inst.p[j] = p_dist(rng);
            if (inst.p[j] <= 1) {
                inst.delta[j] = 0;
            } else {
                double r = r_dist(rng);
                int d = static_cast<int>(ceil(r * static_cast<double>(inst.p[j])));
                inst.delta[j] = min(inst.p[j] - 1, max(0, d));
            }
        }
    }

    inst.sum_p = accumulate(inst.p.begin(), inst.p.end(), 0);
    inst.sum_delta = accumulate(inst.delta.begin(), inst.delta.end(), 0);
    inst.sum_min_p = 0;
    inst.max_min_p = 0;
    for (int j = 0; j < n; ++j) {
        int min_p = max(1, inst.p[j] - inst.delta[j]);
        inst.sum_min_p += min_p;
        inst.max_min_p = max(inst.max_min_p, min_p);
    }
    inst.min_possible_makespan = max(inst.max_min_p, ceilDivInt(inst.sum_min_p, m));

    inst.cstar_raw = static_cast<int>(ceil(static_cast<double>(inst.sum_p) /
                                           (static_cast<double>(m) * target_rho)));
    inst.C_star = inst.cstar_raw;
    inst.cstar_adjusted = false;
    if (inst.C_star < inst.min_possible_makespan) {
        if (ADJUST_INFEASIBLE_CSTAR_TO_MIN_FEASIBLE) {
            inst.C_star = inst.min_possible_makespan;
            inst.cstar_adjusted = true;
        }
    }
    inst.actual_rho = static_cast<double>(inst.sum_p) /
                      (static_cast<double>(m) * static_cast<double>(inst.C_star));
    return inst;
}

void saveInstanceData(const InstanceData& inst, const string& filename) {
    ofstream file(filename.c_str());
    if (!file.is_open()) {
        cerr << "Could not write instance file: " << filename << endl;
        return;
    }

    file << "=== SENSITIVITY INSTANCE DATA ===\n";
    file << "pt_class: " << inst.pt_class << "\n";
    file << "n: " << inst.n << "\n";
    file << "m: " << inst.m << "\n";
    file << "run_id: " << inst.run_id << "\n";
    file << "seed: " << inst.seed << "\n";
    file << "target_rho: " << inst.target_rho << "\n";
    file << "actual_rho: " << inst.actual_rho << "\n";
    file << "C_star_raw: " << inst.cstar_raw << "\n";
    file << "C_star_used: " << inst.C_star << "\n";
    file << "C_star_adjusted: " << (inst.cstar_adjusted ? 1 : 0) << "\n";
    file << "sum_p: " << inst.sum_p << "\n";
    file << "sum_delta: " << inst.sum_delta << "\n";
    file << "sum_min_p: " << inst.sum_min_p << "\n";
    file << "max_min_p: " << inst.max_min_p << "\n";
    file << "min_possible_makespan: " << inst.min_possible_makespan << "\n";
    file << "\njob,p_j,delta_j,min_p\n";
    for (int j = 0; j < inst.n; ++j) {
        file << j << "," << inst.p[j] << "," << inst.delta[j] << ","
             << max(1, inst.p[j] - inst.delta[j]) << "\n";
    }
    file.close();
}

// ----------------------------- Benders solver -----------------------------

/*
 * Corrected paper-style BD implementation.
 * The master/subproblem structure is kept. The optimality cut is generated
 * from a valid subgradient of the total-compression recourse value rather than
 * from p_tilde-weighted LP dual coefficients.
 */


class BendersSolver {
private:
    int numMachines;
    int numJobs;
    vector<int> p;
    vector<int> delta;
    int C_star;
    bool discrete_p_tilde;
    bool verbose;

    IloEnv env;
    IloModel masterModel;
    IloCplex masterSolver;
    IloNumVarArray alpha;
    IloNumVar eta;

    vector<double> best_alpha;
    vector<double> best_p_tilde;
    double best_upper_bound;

public:
    BendersSolver(int M, int N, const vector<int>& p_vec,
                  const vector<int>& delta_vec, int C_target,
                  bool discrete_ptilde = false, bool verbose_output = false)
        : numMachines(M), numJobs(N), p(p_vec), delta(delta_vec), C_star(C_target),
          discrete_p_tilde(discrete_ptilde), verbose(verbose_output),
          env(), masterModel(env), masterSolver(masterModel),
          alpha(env), eta(), best_alpha(M * N, 0.0), best_p_tilde(N, 0.0),
          best_upper_bound(1e100) {
        initializeMasterProblem();
    }

    ~BendersSolver() {
        env.end();
    }

    MethodResult solve();

private:
    void initializeMasterProblem();
    bool solveSubProblem(const vector<double>& alpha_values,
                         double& objective_value,
                         vector<double>& lambda_values,
                         vector<double>& p_tilde_values);
    void addOptimalityCut(double Q, const vector<double>& alpha_bar);
    bool extractAlpha(vector<double>& alpha_values);
};

void BendersSolver::initializeMasterProblem() {
    alpha = IloNumVarArray(env, numMachines * numJobs, 0, 1, ILOINT);
    eta = IloNumVar(env, 0.0, IloInfinity, ILOFLOAT);

    masterModel.add(IloMinimize(env, eta));

    // Each job is assigned to exactly one machine.
    for (int j = 0; j < numJobs; ++j) {
        IloExpr expr(env);
        for (int i = 0; i < numMachines; ++i) {
            expr += alpha[i * numJobs + j];
        }
        masterModel.add(expr == 1);
        expr.end();
    }

    // Feasibility under maximum allowable compression.
    for (int i = 0; i < numMachines; ++i) {
        IloExpr min_load(env);
        for (int j = 0; j < numJobs; ++j) {
            min_load += alpha[i * numJobs + j] * max(1, p[j] - delta[j]);
        }
        masterModel.add(min_load <= C_star);
        min_load.end();
    }
}

bool BendersSolver::extractAlpha(vector<double>& alpha_values) {
    alpha_values.assign(numMachines * numJobs, 0.0);
    for (int i = 0; i < numMachines; ++i) {
        for (int j = 0; j < numJobs; ++j) {
            double v = masterSolver.getValue(alpha[i * numJobs + j]);
            alpha_values[i * numJobs + j] = (v > 0.5 ? 1.0 : 0.0);
        }
    }
    return true;
}

bool BendersSolver::solveSubProblem(const vector<double>& alpha_values,
                                    double& objective_value,
                                    vector<double>& lambda_values,
                                    vector<double>& p_tilde_values) {
    IloEnv subEnv;
    try {
        IloModel subModel(subEnv);

        IloNumVarArray p_tilde(subEnv, numJobs);
        IloNumVar::Type ptilde_type = discrete_p_tilde ? ILOINT : ILOFLOAT;
        for (int j = 0; j < numJobs; ++j) {
            double lb = max(1.0, static_cast<double>(p[j] - delta[j]));
            double ub = static_cast<double>(p[j]);
            p_tilde[j] = IloNumVar(subEnv, lb, ub, ptilde_type);
        }

        IloExpr obj(subEnv);
        for (int j = 0; j < numJobs; ++j) {
            obj += static_cast<double>(p[j]) - p_tilde[j];
        }
        subModel.add(IloMinimize(subEnv, obj));
        obj.end();

        IloRangeArray capacityConstraints(subEnv);
        for (int i = 0; i < numMachines; ++i) {
            IloExpr load(subEnv);
            for (int j = 0; j < numJobs; ++j) {
                if (alpha_values[i * numJobs + j] > 0.5) {
                    load += p_tilde[j];
                }
            }
            capacityConstraints.add(load <= C_star);
            load.end();
        }
        subModel.add(capacityConstraints);

        IloCplex subSolver(subModel);
        subSolver.setOut(subEnv.getNullStream());
        subSolver.setParam(IloCplex::Param::Threads, 1);
        subSolver.setParam(IloCplex::Param::TimeLimit, SUBPROBLEM_TIME_LIMIT_SEC);
        if (!discrete_p_tilde) {
            subSolver.setParam(IloCplex::Param::RootAlgorithm, IloCplex::Dual);
        }

        bool ok = subSolver.solve();
        IloAlgorithm::Status st = subSolver.getStatus();
        if (!ok || !(st == IloAlgorithm::Optimal || st == IloAlgorithm::Feasible)) {
            subEnv.end();
            return false;
        }

        objective_value = subSolver.getObjValue();

        // Dual values are not needed by the current BD_sum cut.
        // For the discrete \tilde{p}_j version, the subproblem is a small MIP,
        // so dual values are not available.
        lambda_values.assign(numMachines, 0.0);
        if (!discrete_p_tilde) {
            for (int i = 0; i < numMachines; ++i) {
                double d = subSolver.getDual(capacityConstraints[i]);
                lambda_values[i] = max(0.0, -d);
            }
        }

        p_tilde_values.assign(numJobs, 0.0);
        for (int j = 0; j < numJobs; ++j) {
            p_tilde_values[j] = subSolver.getValue(p_tilde[j]);
        }

        subEnv.end();
        return true;
    } catch (IloException& e) {
        cerr << "Subproblem error: " << e << endl;
        subEnv.end();
        return false;
    }
}

void BendersSolver::addOptimalityCut(double Q, const vector<double>& alpha_bar) {
    // Valid cut for the total-compression recourse function:
    // eta >= Q(xbar) + sum_{i in I+} sum_j p_j (x_ij - xbar_ij),
    // where I+ contains machines whose original load exceeds C*.
    IloExpr lhs(env);
    lhs += eta;

    double rhs = Q;
    for (int i = 0; i < numMachines; ++i) {
        double original_load_i = 0.0;
        for (int j = 0; j < numJobs; ++j) {
            if (alpha_bar[i * numJobs + j] > 0.5) {
                original_load_i += static_cast<double>(p[j]);
            }
        }

        if (original_load_i > static_cast<double>(C_star) + EPS) {
            for (int j = 0; j < numJobs; ++j) {
                double coeff = static_cast<double>(p[j]);
                lhs -= coeff * alpha[i * numJobs + j];
                rhs -= coeff * alpha_bar[i * numJobs + j];
            }
        }
    }

    masterModel.add(lhs >= rhs);
    lhs.end();
}

MethodResult BendersSolver::solve() {
    MethodResult res;
    auto start = chrono::steady_clock::now();

    try {
        masterSolver.setOut(env.getNullStream());
        masterSolver.setParam(IloCplex::Param::MIP::Tolerances::MIPGap, 1e-6);
        masterSolver.setParam(IloCplex::Param::Threads, 1);
        masterSolver.setParam(IloCplex::Param::TimeLimit, MASTER_TIME_LIMIT_SEC);

        double UB = 1e100;
        double LB = 0.0;
        int iter = 0;
        vector<double> alpha_bar;
        vector<double> lambda_values;
        vector<double> p_tilde_values;

        for (iter = 1; iter <= MAX_BD_ITERATIONS; ++iter) {
            bool master_ok = masterSolver.solve();
            IloAlgorithm::Status mst = masterSolver.getStatus();
            if (!master_ok || !(mst == IloAlgorithm::Optimal || mst == IloAlgorithm::Feasible)) {
                res.status = string("Master_") + cplexStatusToString(mst);
                res.feasible = false;
                res.solved = false;
                break;
            }

            LB = masterSolver.getObjValue();
            extractAlpha(alpha_bar);

            double Q = 0.0;
            bool sub_ok = solveSubProblem(alpha_bar, Q, lambda_values, p_tilde_values);
            if (!sub_ok) {
                res.status = "SubproblemInfeasibleOrFailed";
                res.feasible = false;
                res.solved = false;
                break;
            }

            if (Q < UB - EPS) {
                UB = Q;
                best_upper_bound = UB;
                best_alpha = alpha_bar;
                best_p_tilde = p_tilde_values;
            }

            addOptimalityCut(Q, alpha_bar);

            double abs_gap = UB - LB;
            double rel_gap = abs_gap / max(1.0, fabs(UB));

            if (verbose) {
                cout << "BD iter " << iter
                     << ": LB=" << LB
                     << ", UB=" << UB
                     << ", gap=" << rel_gap * 100.0 << "%" << endl;
            }

            if (abs_gap <= EPS * max(1.0, fabs(UB))) {
                res.feasible = true;
                res.solved = true;
                res.optimal = true;
                res.status = "Optimal";
                res.objective = UB;
                res.best_bound = LB;
                res.gap = 0.0;
                res.iterations = iter;
                break;
            }
        }

        if (!res.solved && best_upper_bound < 1e90) {
            res.feasible = true;
            res.solved = true;
            res.optimal = false;
            res.status = (iter > MAX_BD_ITERATIONS ? "MaxIterations" : "StoppedWithIncumbent");
            res.objective = best_upper_bound;
            res.best_bound = LB;
            res.gap = (best_upper_bound - LB) / max(1.0, fabs(best_upper_bound));
            res.iterations = min(iter, MAX_BD_ITERATIONS);
        }
    } catch (IloException& e) {
        cerr << "Benders error: " << e << endl;
        res.status = "Error";
        res.feasible = false;
        res.solved = false;
    }

    auto end = chrono::steady_clock::now();
    res.time_sec = chrono::duration<double>(end - start).count();
    if (res.time_sec >= MASTER_TIME_LIMIT_SEC - 1.0) res.time_limit = true;
    return res;
}

// ----------------------------- Direct MIP solver -----------------------------

MethodResult solveWithDirectMIP(const InstanceData& inst, bool discrete_p_tilde) {
    MethodResult res;
    auto start = chrono::steady_clock::now();

    IloEnv env;
    try {
        IloModel model(env);
        int m = inst.m;
        int n = inst.n;

        IloArray<IloBoolVarArray> x(env, m);
        for (int i = 0; i < m; ++i) {
            x[i] = IloBoolVarArray(env, n);
        }

        IloNumVarArray p_tilde(env, n);
        IloNumVar::Type ptilde_type = discrete_p_tilde ? ILOINT : ILOFLOAT;
        for (int j = 0; j < n; ++j) {
            double lb = max(1.0, static_cast<double>(inst.p[j] - inst.delta[j]));
            double ub = static_cast<double>(inst.p[j]);
            p_tilde[j] = IloNumVar(env, lb, ub, ptilde_type);
        }

        IloExpr obj(env);
        for (int j = 0; j < n; ++j) {
            obj += static_cast<double>(inst.p[j]) - p_tilde[j];
        }
        model.add(IloMinimize(env, obj));
        obj.end();

        for (int j = 0; j < n; ++j) {
            IloExpr assign(env);
            for (int i = 0; i < m; ++i) assign += x[i][j];
            model.add(assign == 1);
            assign.end();
        }

        // w_ij = x_ij * p_tilde_j linearization.
        IloArray<IloNumVarArray> w(env, m);
        for (int i = 0; i < m; ++i) {
            w[i] = IloNumVarArray(env, n);
            for (int j = 0; j < n; ++j) {
                double lb = max(1.0, static_cast<double>(inst.p[j] - inst.delta[j]));
                double ub = static_cast<double>(inst.p[j]);
                w[i][j] = IloNumVar(env, 0.0, ub, ILOFLOAT);
                model.add(w[i][j] <= ub * x[i][j]);
                model.add(w[i][j] >= lb * x[i][j]);
                model.add(w[i][j] <= p_tilde[j]);
                model.add(w[i][j] >= p_tilde[j] - ub * (1 - x[i][j]));
            }
        }

        for (int i = 0; i < m; ++i) {
            IloExpr load(env);
            for (int j = 0; j < n; ++j) load += w[i][j];
            model.add(load <= inst.C_star);
            load.end();
        }

        IloCplex cplex(model);
        cplex.setOut(env.getNullStream());
        cplex.setParam(IloCplex::Param::TimeLimit, MIP_TIME_LIMIT_SEC);
        cplex.setParam(IloCplex::Param::MIP::Tolerances::MIPGap, 1e-6);
        cplex.setParam(IloCplex::Param::Threads, 1);

        bool ok = cplex.solve();
        IloAlgorithm::Status st = cplex.getStatus();
        res.status = cplexStatusToString(st);
        if (ok && (st == IloAlgorithm::Optimal || st == IloAlgorithm::Feasible)) {
            res.feasible = true;
            res.solved = true;
            res.optimal = (st == IloAlgorithm::Optimal);
            res.objective = cplex.getObjValue();
            try {
                res.best_bound = cplex.getBestObjValue();
            } catch (...) {
                res.best_bound = numeric_limits<double>::quiet_NaN();
            }
            try {
                res.gap = cplex.getMIPRelativeGap();
            } catch (...) {
                res.gap = numeric_limits<double>::quiet_NaN();
            }
        } else {
            res.feasible = false;
            res.solved = false;
        }
    } catch (IloException& e) {
        cerr << "Direct MIP error: " << e << endl;
        res.status = "Error";
    }

    env.end();
    auto end = chrono::steady_clock::now();
    res.time_sec = chrono::duration<double>(end - start).count();
    if (res.time_sec >= MIP_TIME_LIMIT_SEC - 1.0) res.time_limit = true;
    return res;
}

// ----------------------------- Output functions -----------------------------

void writeDetailedCsvHeader(ofstream& file) {
    file << "pt_class,ptilde_mode,target_rho,actual_rho,n,m,run_id,seed,"
         << "sum_p,sum_delta,sum_min_p,min_possible_makespan,Cstar_raw,Cstar_used,Cstar_adjusted,"
         << "bd_status,bd_optimal,bd_obj,bd_norm_obj,bd_time,bd_gap,bd_iterations,"
         << "mip_status,mip_optimal,mip_obj,mip_norm_obj,mip_time,mip_gap,mip_best_bound,"
         << "abs_obj_diff\n";
}

void appendDetailedCsvRow(ofstream& file, const RunResult& r) {
    const InstanceData& inst = r.inst;
    file << inst.pt_class << ","
         << r.ptilde_mode << ","
         << fixed << setprecision(6) << inst.target_rho << ","
         << fixed << setprecision(6) << inst.actual_rho << ","
         << inst.n << "," << inst.m << "," << inst.run_id << "," << inst.seed << ","
         << inst.sum_p << "," << inst.sum_delta << "," << inst.sum_min_p << ","
         << inst.min_possible_makespan << "," << inst.cstar_raw << "," << inst.C_star << ","
         << (inst.cstar_adjusted ? 1 : 0) << ","
         << r.bd.status << "," << (r.bd.optimal ? 1 : 0) << ","
         << r.bd.objective << "," << r.bd_norm_obj << "," << r.bd.time_sec << ","
         << r.bd.gap << "," << r.bd.iterations << ","
         << r.mip.status << "," << (r.mip.optimal ? 1 : 0) << ","
         << r.mip.objective << "," << r.mip_norm_obj << "," << r.mip.time_sec << ","
         << r.mip.gap << "," << r.mip.best_bound << ","
         << r.abs_obj_diff << "\n";
}

void writeSummaryCsv(const vector<RunResult>& all_runs, const string& filename) {
    ofstream file(filename.c_str());
    if (!file.is_open()) {
        cerr << "Could not write summary CSV: " << filename << endl;
        return;
    }

    file << "pt_class,ptilde_mode,target_rho,n,m,runs,adjusted_Cstar_count,"
         << "mean_actual_rho,"
         << "bd_optimal_count,bd_mean_obj,bd_std_obj,bd_mean_norm_obj,bd_mean_time,bd_std_time,bd_mean_gap,"
         << "mip_feasible_count,mip_optimal_count,mip_time_limit_count,mip_mean_obj,mip_std_obj,"
         << "mip_mean_norm_obj,mip_mean_time,mip_std_time,mip_mean_gap,mean_abs_obj_diff\n";

    vector<string> pt_classes;
    pt_classes.push_back("PT-N");
    pt_classes.push_back("PT-W");
    vector<string> ptilde_modes;
    ptilde_modes.push_back(PTILDE_CONTINUOUS);
    ptilde_modes.push_back(PTILDE_DISCRETE);

    vector<double> rhos;
    rhos.push_back(1.05);
    rhos.push_back(1.15);
    rhos.push_back(1.25);
    vector<pair<int,int> > configs;
    configs.push_back(make_pair(20, 2));
    configs.push_back(make_pair(20, 3));
    configs.push_back(make_pair(20, 5));
    configs.push_back(make_pair(30, 2));
    configs.push_back(make_pair(30, 3));
    configs.push_back(make_pair(30, 5));
    configs.push_back(make_pair(30, 10));
    configs.push_back(make_pair(50, 2));
    configs.push_back(make_pair(50, 3));
    configs.push_back(make_pair(50, 5));
    configs.push_back(make_pair(50, 10));
    configs.push_back(make_pair(100, 2));
    configs.push_back(make_pair(100, 3));
    configs.push_back(make_pair(100, 5));
    configs.push_back(make_pair(100, 10));
    configs.push_back(make_pair(200, 2));
    configs.push_back(make_pair(200, 3));
    configs.push_back(make_pair(200, 5));
    configs.push_back(make_pair(200, 10));

    for (size_t pc = 0; pc < pt_classes.size(); ++pc) {
        for (size_t pm = 0; pm < ptilde_modes.size(); ++pm) {
            for (size_t rr = 0; rr < rhos.size(); ++rr) {
                for (size_t cc = 0; cc < configs.size(); ++cc) {
                    string pt = pt_classes[pc];
                    string ptilde_mode = ptilde_modes[pm];
                    double rho = rhos[rr];
                    int n = configs[cc].first;
                    int m = configs[cc].second;

                    vector<double> actual_rhos, bd_objs, bd_norms, bd_times, bd_gaps;
                    vector<double> mip_objs, mip_norms, mip_times, mip_gaps, diffs;
                    int runs = 0;
                    int adjusted_count = 0;
                    int bd_optimal_count = 0;
                    int mip_feasible_count = 0;
                    int mip_optimal_count = 0;
                    int mip_tl_count = 0;

                    for (size_t k = 0; k < all_runs.size(); ++k) {
                        const RunResult& r = all_runs[k];
                        if (r.inst.pt_class == pt && r.ptilde_mode == ptilde_mode &&
                            fabs(r.inst.target_rho - rho) < 1e-9 &&
                            r.inst.n == n && r.inst.m == m) {
                            runs++;
                            if (r.inst.cstar_adjusted) adjusted_count++;
                            actual_rhos.push_back(r.inst.actual_rho);
                            if (r.bd.optimal) bd_optimal_count++;
                            if (r.bd.solved) {
                                bd_objs.push_back(r.bd.objective);
                                bd_norms.push_back(r.bd_norm_obj);
                                bd_times.push_back(r.bd.time_sec);
                                if (!std::isnan(r.bd.gap)) bd_gaps.push_back(r.bd.gap);
                            }
                            if (r.mip.feasible) mip_feasible_count++;
                            if (r.mip.optimal) mip_optimal_count++;
                            if (r.mip.time_limit) mip_tl_count++;
                            if (r.mip.solved) {
                                mip_objs.push_back(r.mip.objective);
                                mip_norms.push_back(r.mip_norm_obj);
                                mip_times.push_back(r.mip.time_sec);
                                if (!std::isnan(r.mip.gap)) mip_gaps.push_back(r.mip.gap);
                            }
                            if (!std::isnan(r.abs_obj_diff)) diffs.push_back(r.abs_obj_diff);
                        }
                    }

                    file << pt << "," << ptilde_mode << "," << fixed << setprecision(6) << rho << ","
                         << n << "," << m << "," << runs << "," << adjusted_count << ","
                         << meanValue(actual_rhos) << ","
                         << bd_optimal_count << ","
                         << meanValue(bd_objs) << "," << stdValue(bd_objs) << ","
                         << meanValue(bd_norms) << ","
                         << meanValue(bd_times) << "," << stdValue(bd_times) << ","
                         << meanValue(bd_gaps) << ","
                         << mip_feasible_count << "," << mip_optimal_count << "," << mip_tl_count << ","
                         << meanValue(mip_objs) << "," << stdValue(mip_objs) << ","
                         << meanValue(mip_norms) << "," << meanValue(mip_times) << "," << stdValue(mip_times) << ","
                         << meanValue(mip_gaps) << "," << meanValue(diffs) << "\n";
                }
            }
        }
    }

    file.close();
}

// ----------------------------- Experiment runner -----------------------------

RunResult runSingleSensitivityExperiment(int n, int m, const string& pt_class,
                                         double rho, int run_id,
                                         const string& ptilde_mode,
                                         const string& instance_dir) {
    RunResult result;
    result.inst = generateSensitivityInstance(n, m, pt_class, rho, run_id);
    result.ptilde_mode = ptilde_mode;
    bool discrete_p_tilde = isDiscretePtildeMode(ptilde_mode);

    string inst_label = pt_class + "_rho" + sanitizeRho(rho) + "_n" + to_string(n) +
                        "_m" + to_string(m) + "_run" + to_string(run_id);
    string inst_file = instance_dir + "/instance_" + inst_label + ".csv";
    saveInstanceData(result.inst, inst_file);

    BendersSolver bd(result.inst.m, result.inst.n, result.inst.p, result.inst.delta,
                     result.inst.C_star, discrete_p_tilde, false);
    result.bd = bd.solve();

    result.mip = solveWithDirectMIP(result.inst, discrete_p_tilde);

    if (result.bd.solved && result.mip.solved) {
        result.abs_obj_diff = fabs(result.bd.objective - result.mip.objective);
    } else {
        result.abs_obj_diff = numeric_limits<double>::quiet_NaN();
    }

    if (result.inst.sum_delta > 0 && result.bd.solved) {
        result.bd_norm_obj = result.bd.objective / static_cast<double>(result.inst.sum_delta);
    } else {
        result.bd_norm_obj = numeric_limits<double>::quiet_NaN();
    }

    if (result.inst.sum_delta > 0 && result.mip.solved) {
        result.mip_norm_obj = result.mip.objective / static_cast<double>(result.inst.sum_delta);
    } else {
        result.mip_norm_obj = numeric_limits<double>::quiet_NaN();
    }

    return result;
}

int main() {
    string timestamp = getCurrentTimestamp();
    string base_dir = "/Users/a1407/Desktop/parallelM/experiment_" + timestamp;
    string instance_dir = base_dir + "/instances";

    makeDirectory(base_dir);
    makeDirectory(instance_dir);

    string detailed_csv = base_dir + "/sensitivity_detailed_results_" + timestamp + ".csv";
    string summary_csv = base_dir + "/sensitivity_summary_results_" + timestamp + ".csv";
    string readme_file = base_dir + "/README_" + timestamp + ".txt";

    vector<string> pt_classes;
  //  pt_classes.push_back("PT-N");
    pt_classes.push_back("PT-W");

    vector<string> ptilde_modes;
    ptilde_modes.push_back(PTILDE_CONTINUOUS);
    ptilde_modes.push_back(PTILDE_DISCRETE);

    vector<double> load_levels;
    load_levels.push_back(1.05);
   // load_levels.push_back(1.15);
   // load_levels.push_back(1.25);

    // Problem-size configurations consistent with the revised manuscript.
    vector<pair<int,int> > configurations;
    configurations.push_back(make_pair(20, 2));
    configurations.push_back(make_pair(20, 3));
    configurations.push_back(make_pair(20, 5));
    configurations.push_back(make_pair(30, 2));
    configurations.push_back(make_pair(30, 3));
    configurations.push_back(make_pair(30, 5));
    configurations.push_back(make_pair(30, 10));
    configurations.push_back(make_pair(50, 2));
    configurations.push_back(make_pair(50, 3));
    configurations.push_back(make_pair(50, 5));
    configurations.push_back(make_pair(50, 10));
    configurations.push_back(make_pair(100, 2));
    configurations.push_back(make_pair(100, 3));
    configurations.push_back(make_pair(100, 5));
    configurations.push_back(make_pair(100, 10));
    configurations.push_back(make_pair(200, 2));
    configurations.push_back(make_pair(200, 3));
    configurations.push_back(make_pair(200, 5));
    configurations.push_back(make_pair(200, 10));

    ofstream readme(readme_file.c_str());
    if (readme.is_open()) {
        readme << "Sensitivity analysis for total-compression RIPMSP\n";
        readme << "Timestamp: " << timestamp << "\n";
        readme << "Output directory: " << base_dir << "\n\n";
        readme << "Processing-time classes:\n";
        readme << "  PT-N: p_j ~ U[10,24], delta_j ~ U[1,5]\n";
        readme << "  PT-W: p_j ~ U[1,100], delta_j = min{p_j-1, ceil(r_j p_j)}, r_j ~ U[0.10,0.30]\n\n";
        readme << "Adjusted processing-time domains:\n";
        readme << "  CONTINUOUS: \\tilde{p}_j is continuous in [p_j-delta_j, p_j].\n";
        readme << "  DISCRETE:   \\tilde{p}_j is integer in [p_j-delta_j, p_j].\n\n";

        readme << "Machine-load levels:\n";
        readme << "  rho in {1.05, 1.15, 1.25}, rho = sum p_j / (m C*)\n";
        readme << "  C*(rho) = ceil(sum p_j / (m rho))\n";
        readme << "  If C*(rho) is below the full-compression feasibility lower bound, C* is adjusted to the minimum feasible value and recorded.\n\n";
        readme << "Problem-size configurations:\n";
        for (size_t c = 0; c < configurations.size(); ++c) {
            readme << "  n=" << configurations[c].first << ", m=" << configurations[c].second << "\n";
        }
        readme << "\nTime limits:\n";
        readme << "  BD master time limit: " << MASTER_TIME_LIMIT_SEC << " seconds\n";
        readme << "  BD subproblem time limit: " << SUBPROBLEM_TIME_LIMIT_SEC << " seconds\n";
        readme << "  Direct MIP time limit: " << MIP_TIME_LIMIT_SEC << " seconds\n";
        readme.close();
    }

    ofstream detailed(detailed_csv.c_str());
    if (!detailed.is_open()) {
        cerr << "Could not open detailed CSV for writing: " << detailed_csv << endl;
        return 1;
    }
    writeDetailedCsvHeader(detailed);

    vector<RunResult> all_runs;
    int total_runs = static_cast<int>(pt_classes.size() * ptilde_modes.size() * load_levels.size() *
                                      configurations.size() * NUM_RUNS_PER_COMBINATION);
    int finished = 0;

    cout << "=== TOTAL-COMPRESSION SENSITIVITY ANALYSIS ===" << endl;
    cout << "Output directory: " << base_dir << endl;
    cout << "Total runs: " << total_runs << endl;

    for (size_t pc = 0; pc < pt_classes.size(); ++pc) {
        for (size_t rr = 0; rr < load_levels.size(); ++rr) {
            for (size_t cc = 0; cc < configurations.size(); ++cc) {
                int n = configurations[cc].first;
                int m = configurations[cc].second;
                string pt = pt_classes[pc];
                double rho = load_levels[rr];

                cout << "\n--- Combination: " << pt << ", rho=" << rho
                     << ", n=" << n << ", m=" << m << " ---" << endl;

                for (int run_id = 1; run_id <= NUM_RUNS_PER_COMBINATION; ++run_id) {
                    for (size_t pm = 0; pm < ptilde_modes.size(); ++pm) {
                        string ptilde_mode = ptilde_modes[pm];
                        RunResult r = runSingleSensitivityExperiment(n, m, pt, rho, run_id,
                                                                     ptilde_mode, instance_dir);
                        all_runs.push_back(r);
                        appendDetailedCsvRow(detailed, r);
                        detailed.flush();

                        finished++;
                        cout << "Run " << setw(3) << finished << "/" << total_runs
                             << " | " << pt << " " << shortPtildeMode(ptilde_mode)
                             << " rho=" << fixed << setprecision(2) << rho
                             << " n" << n << "m" << m << " run" << run_id
                             << " | C*=" << r.inst.C_star
                             << (r.inst.cstar_adjusted ? "(adj)" : "")
                             << " | BD=" << r.bd.status << ", obj=" << r.bd.objective
                             << ", time=" << setprecision(3) << r.bd.time_sec
                             << " | MIP=" << r.mip.status << ", obj=" << r.mip.objective
                             << ", gap=" << r.mip.gap
                             << ", time=" << r.mip.time_sec << endl;
                    }
                }
            }
        }
    }

    detailed.close();
    writeSummaryCsv(all_runs, summary_csv);

    cout << "\n=== EXPERIMENT COMPLETED ===" << endl;
    cout << "Detailed CSV: " << detailed_csv << endl;
    cout << "Summary CSV:  " << summary_csv << endl;
    cout << "Instance data: " << instance_dir << endl;
    return 0;
}
