#include <ilcplex/ilocplex.h>
#include <vector>
#include <iostream>
#include <fstream>
#include <sstream>
#include <numeric>
#include <cmath>
#include <algorithm>
#include <ctime>
#include <iomanip>
#include <random>
#include <string>
#include <limits>
#include <cstdlib>
#include <chrono>

ILOSTLBEGIN

using namespace std;

/*
 * Load-factor computational experiment for the maximum-compression RIPMSP.
 *
 * Purpose:
 *   Extend the uploaded maximum-compression algorithms to all n-m configurations used
 *   in the total-compression experiment, and compare both continuous and discrete
 *   compressed processing-time variables \tilde{p}_j.
 *
 * Compared methods for each instance and each variant:
 *   1) H_max heuristic
 *   2) BD_max heuristic / BD-based assignment search
 *   3) Matheuristic: BD_sum lower bound + best warm start + bounded MIP
 *   4) Direct MIP
 *
 * Instance generation follows the load-controlled sensitivity setting:
 *   PT-N: p_j ~ U[10,24], delta_j ~ U[1,5]
 *   PT-W: p_j ~ U[1,100], delta_j = min{p_j-1, ceil(r_j p_j)}, r_j ~ U[0.10,0.30]
 *   rho in {1.05, 1.15, 1.25}, where rho = sum_j p_j/(m C*)
 *   C*(rho) = ceil(sum_j p_j/(m rho)); if this is below the full-compression
 *     feasibility lower bound, it is adjusted to that lower bound and recorded.
 *   10 instances per pt-class/n-m-rho configuration.
 *
 * Output root is kept consistent with the previous experiment code.
 * Change OUTPUT_ROOT only if you want a different folder.
 *
 * Compatibility:
 *   - CPLEX 12.7 / Xcode 14.2
 *   - C++14; no std::filesystem.
 */

// ----------------------------- Global settings -----------------------------

static const double EPS = 1e-6;
static const double MASTER_TIME_LIMIT_SEC = 900.0;
static const double SUBPROBLEM_TIME_LIMIT_SEC = 900.0;
static const double DIRECT_MIP_TIME_LIMIT_SEC = 900.0;
static const double MATHEURISTIC_MIP_TIME_LIMIT_SEC = 900.0;
static const int MAX_BD_ITERATIONS = 1000;
static const int MAX_NO_IMPROVE_ITERATIONS = 20;
static const int NUM_RUNS_PER_CONFIGURATION = 10;
static const bool ADJUST_INFEASIBLE_CSTAR_TO_MIN_FEASIBLE = true;

// Previous output root used by the total-compression experiment code.
static const string OUTPUT_ROOT = "/Users/shijinwang/Desktop/sensitivityanalysis";

enum PTildeType { PTILDE_CONTINUOUS = 0, PTILDE_DISCRETE = 1 };

string typeName(PTildeType t) {
    return (t == PTILDE_CONTINUOUS ? "continuous" : "discrete");
}

// ----------------------------- Utility functions ----------------------------

string getCurrentTimestamp() {
    time_t now = time(NULL);
    tm* local_time = localtime(&now);
    char buffer[64];
    strftime(buffer, sizeof(buffer), "%Y%m%d_%H%M%S", local_time);
    return string(buffer);
}

string sanitizeRho(double rho) {
    stringstream ss;
    ss << fixed << setprecision(2) << rho;
    string out = ss.str();
    replace(out.begin(), out.end(), '.', 'p');
    return out;
}

void makeDirectory(const string& dir) {
    string cmd = "mkdir -p \"" + dir + "\"";
    int ret = system(cmd.c_str());
    if (ret != 0) cerr << "Warning: could not create directory: " << dir << endl;
}

int ceilDivInt(int a, int b) {
    return (a + b - 1) / b;
}

template<typename T>
double meanValue(const vector<T>& values) {
    if (values.empty()) return numeric_limits<double>::quiet_NaN();
    double s = 0.0;
    for (size_t i = 0; i < values.size(); ++i) s += static_cast<double>(values[i]);
    return s / static_cast<double>(values.size());
}

template<typename T>
double stdValue(const vector<T>& values) {
    if (values.size() <= 1) return 0.0;
    double m = meanValue(values);
    double v = 0.0;
    for (size_t i = 0; i < values.size(); ++i) {
        double d = static_cast<double>(values[i]) - m;
        v += d * d;
    }
    v /= static_cast<double>(values.size());
    return sqrt(v);
}

string cplexStatusToString(IloAlgorithm::Status st) {
    switch (st) {
        case IloAlgorithm::Optimal: return "Optimal";
        case IloAlgorithm::Feasible: return "Feasible";
        case IloAlgorithm::Infeasible: return "Infeasible";
        case IloAlgorithm::Unbounded: return "Unbounded";
        case IloAlgorithm::InfeasibleOrUnbounded: return "InfeasibleOrUnbounded";
        case IloAlgorithm::Unknown: return "Unknown";
        case IloAlgorithm::Error: return "Error";
        default: return "Other";
    }
}

string doubleToCsv(double x) {
    if (std::isnan(x)) return "NA";
    stringstream ss;
    ss << fixed << setprecision(6) << x;
    return ss.str();
}

// ----------------------------- Data structures -----------------------------

struct InstanceData {
    string pt_class;
    int n;
    int m;
    int run_id;
    unsigned int seed;
    double target_rho;
    double actual_rho;
    vector<int> p;
    vector<int> delta;
    int sum_p;
    int sum_delta;
    int sum_min_p;
    int max_min_p;
    int min_possible_makespan;
    int cstar_raw;
    int C_star;
    bool cstar_adjusted;
};

struct SolutionData {
    vector<double> alpha;      // flattened i*n+j
    vector<double> p_tilde;
    double objective;
    SolutionData() : objective(numeric_limits<double>::quiet_NaN()) {}
};

struct MethodResult {
    bool feasible;
    bool solved;
    bool optimal;
    bool time_limit;
    string status;
    double objective;
    double best_bound;
    double gap;
    double time_sec;
    int iterations;
    SolutionData sol;

    MethodResult()
        : feasible(false), solved(false), optimal(false), time_limit(false), status("NotRun"),
          objective(numeric_limits<double>::quiet_NaN()),
          best_bound(numeric_limits<double>::quiet_NaN()),
          gap(numeric_limits<double>::quiet_NaN()), time_sec(0.0), iterations(0) {}
};

struct RunResult {
    InstanceData inst;
    PTildeType ptype;
    MethodResult hmax;
    MethodResult bdmax;
    MethodResult matheuristic;
    MethodResult mip;
};

// ----------------------------- Instance generation -----------------------------

InstanceData generateInstance(int n, int m, const string& pt_class, int run_id, double target_rho) {
    InstanceData inst;
    inst.pt_class = pt_class;
    inst.n = n;
    inst.m = m;
    inst.run_id = run_id;
    inst.target_rho = target_rho;

    int pt_code = (pt_class == "PT-W") ? 2 : 1;
    int rho_code = static_cast<int>(round(target_rho * 100.0));
    // Same seed logic as the total-compression sensitivity experiment.
    inst.seed = 20260429u + static_cast<unsigned int>(1000003 * run_id)
                + static_cast<unsigned int>(10007 * n)
                + static_cast<unsigned int>(1009 * m)
                + static_cast<unsigned int>(101 * pt_code)
                + static_cast<unsigned int>(17 * rho_code);

    mt19937 rng(inst.seed);
    inst.p.assign(n, 0);
    inst.delta.assign(n, 0);

    if (pt_class == "PT-N") {
        uniform_int_distribution<int> p_dist(10, 24);
        uniform_int_distribution<int> d_dist(1, 5);
        for (int j = 0; j < n; ++j) {
            inst.p[j] = p_dist(rng);
            inst.delta[j] = d_dist(rng);
            inst.delta[j] = min(inst.delta[j], max(0, inst.p[j] - 1));
        }
    } else {
        uniform_int_distribution<int> p_dist(1, 100);
        uniform_real_distribution<double> r_dist(0.10, 0.30);
        for (int j = 0; j < n; ++j) {
            inst.p[j] = p_dist(rng);
            if (inst.p[j] <= 1) {
                inst.delta[j] = 0;
            } else {
                double r = r_dist(rng);
                int d = static_cast<int>(ceil(r * static_cast<double>(inst.p[j])));
                inst.delta[j] = min(inst.p[j] - 1, max(0, d));
            }
        }
    }

    inst.sum_p = accumulate(inst.p.begin(), inst.p.end(), 0);
    inst.sum_delta = accumulate(inst.delta.begin(), inst.delta.end(), 0);
    inst.sum_min_p = 0;
    inst.max_min_p = 0;
    for (int j = 0; j < n; ++j) {
        int min_p = max(1, inst.p[j] - inst.delta[j]);
        inst.sum_min_p += min_p;
        inst.max_min_p = max(inst.max_min_p, min_p);
    }

    inst.min_possible_makespan = max(inst.max_min_p, ceilDivInt(inst.sum_min_p, m));
    inst.cstar_raw = static_cast<int>(ceil(static_cast<double>(inst.sum_p) /
                                           (static_cast<double>(m) * target_rho)));
    inst.C_star = inst.cstar_raw;
    inst.cstar_adjusted = false;
    if (inst.C_star < inst.min_possible_makespan) {
        if (ADJUST_INFEASIBLE_CSTAR_TO_MIN_FEASIBLE) {
            inst.C_star = inst.min_possible_makespan;
            inst.cstar_adjusted = true;
        }
    }
    inst.actual_rho = static_cast<double>(inst.sum_p) /
                      (static_cast<double>(m) * static_cast<double>(inst.C_star));
    return inst;
}

void saveInstanceData(const InstanceData& inst, const string& filename) {
    ofstream file(filename.c_str());
    if (!file.is_open()) {
        cerr << "Could not write instance file: " << filename << endl;
        return;
    }
    file << "pt_class," << inst.pt_class << "\n";
    file << "n," << inst.n << "\n";
    file << "m," << inst.m << "\n";
    file << "run_id," << inst.run_id << "\n";
    file << "seed," << inst.seed << "\n";
    file << "target_rho," << fixed << setprecision(6) << inst.target_rho << "\n";
    file << "actual_rho," << fixed << setprecision(6) << inst.actual_rho << "\n";
    file << "sum_p," << inst.sum_p << "\n";
    file << "sum_delta," << inst.sum_delta << "\n";
    file << "sum_min_p," << inst.sum_min_p << "\n";
    file << "max_min_p," << inst.max_min_p << "\n";
    file << "min_possible_makespan," << inst.min_possible_makespan << "\n";
    file << "C_star_raw," << inst.cstar_raw << "\n";
    file << "C_star_used," << inst.C_star << "\n";
    file << "C_star_adjusted," << (inst.cstar_adjusted ? 1 : 0) << "\n\n";
    file << "job,p_j,delta_j,min_p\n";
    for (int j = 0; j < inst.n; ++j) {
        file << j << "," << inst.p[j] << "," << inst.delta[j] << ","
             << max(1, inst.p[j] - inst.delta[j]) << "\n";
    }
    file.close();
}

// ----------------------------- Feasibility helpers -----------------------------

bool checkSolutionFeasibility(const InstanceData& inst,
                              const vector<double>& alpha,
                              const vector<double>& p_tilde,
                              PTildeType ptype,
                              double* max_dev_out = NULL,
                              double* max_load_out = NULL) {
    if ((int)alpha.size() != inst.m * inst.n || (int)p_tilde.size() != inst.n) return false;
    vector<double> loads(inst.m, 0.0);
    vector<int> assigned_count(inst.n, 0);
    double max_dev = 0.0;
    for (int j = 0; j < inst.n; ++j) {
        double lb = max(1.0, static_cast<double>(inst.p[j] - inst.delta[j]));
        double ub = static_cast<double>(inst.p[j]);
        if (p_tilde[j] < lb - 1e-5 || p_tilde[j] > ub + 1e-5) return false;
        if (ptype == PTILDE_DISCRETE && fabs(p_tilde[j] - round(p_tilde[j])) > 1e-5) return false;
        max_dev = max(max_dev, static_cast<double>(inst.p[j]) - p_tilde[j]);
    }
    for (int i = 0; i < inst.m; ++i) {
        for (int j = 0; j < inst.n; ++j) {
            double a = alpha[i * inst.n + j];
            if (a > 0.5) {
                assigned_count[j]++;
                loads[i] += p_tilde[j];
            }
        }
    }
    for (int j = 0; j < inst.n; ++j) if (assigned_count[j] != 1) return false;
    double max_load = 0.0;
    for (int i = 0; i < inst.m; ++i) {
        max_load = max(max_load, loads[i]);
        if (loads[i] > inst.C_star + 1e-5) return false;
    }
    if (max_dev_out) *max_dev_out = max_dev;
    if (max_load_out) *max_load_out = max_load;
    return true;
}

// ----------------------------- Direct MIP for maximum compression -----------------------------

MethodResult solveMaxCompressionMIP(const InstanceData& inst,
                                    PTildeType ptype,
                                    double time_limit_sec,
                                    const SolutionData* warm_start = NULL,
                                    double z_lower_bound = numeric_limits<double>::quiet_NaN(),
                                    double z_upper_bound = numeric_limits<double>::quiet_NaN()) {
    MethodResult res;
    auto start = chrono::steady_clock::now();

    IloEnv env;
    try {
        IloModel model(env);
        int m = inst.m;
        int n = inst.n;

        IloArray<IloBoolVarArray> x(env, m);
        for (int i = 0; i < m; ++i) x[i] = IloBoolVarArray(env, n);

        IloNumVarArray p_tilde(env, n);
        for (int j = 0; j < n; ++j) {
            double lb = max(1.0, static_cast<double>(inst.p[j] - inst.delta[j]));
            double ub = static_cast<double>(inst.p[j]);
            p_tilde[j] = IloNumVar(env, lb, ub,
                                   (ptype == PTILDE_DISCRETE ? ILOINT : ILOFLOAT));
        }

        IloNumVar z(env, 0.0, IloInfinity,
                    (ptype == PTILDE_DISCRETE ? ILOINT : ILOFLOAT));
        model.add(IloMinimize(env, z));

        if (!std::isnan(z_lower_bound)) model.add(z >= z_lower_bound - EPS);
        if (!std::isnan(z_upper_bound)) model.add(z <= z_upper_bound + EPS);

        for (int j = 0; j < n; ++j) {
            model.add(z >= static_cast<double>(inst.p[j]) - p_tilde[j]);
        }

        for (int j = 0; j < n; ++j) {
            IloExpr assign(env);
            for (int i = 0; i < m; ++i) assign += x[i][j];
            model.add(assign == 1);
            assign.end();
        }

        IloArray<IloNumVarArray> y(env, m);
        for (int i = 0; i < m; ++i) {
            y[i] = IloNumVarArray(env, n);
            for (int j = 0; j < n; ++j) {
                double lb = max(1.0, static_cast<double>(inst.p[j] - inst.delta[j]));
                double ub = static_cast<double>(inst.p[j]);
                y[i][j] = IloNumVar(env, 0.0, ub, ILOFLOAT);
                model.add(y[i][j] <= ub * x[i][j]);
                model.add(y[i][j] >= lb * x[i][j]);
                model.add(y[i][j] <= p_tilde[j]);
                model.add(y[i][j] >= p_tilde[j] - ub * (1 - x[i][j]));
            }
        }

        for (int i = 0; i < m; ++i) {
            IloExpr load(env);
            for (int j = 0; j < n; ++j) load += y[i][j];
            model.add(load <= inst.C_star);
            load.end();
        }

        IloCplex cplex(model);
        cplex.setOut(env.getNullStream());
        cplex.setParam(IloCplex::Param::TimeLimit, time_limit_sec);
        cplex.setParam(IloCplex::Param::Threads, 1);
        cplex.setParam(IloCplex::Param::MIP::Tolerances::MIPGap, 1e-6);

        if (warm_start && !warm_start->alpha.empty() && !warm_start->p_tilde.empty()) {
            IloNumVarArray startVars(env);
            IloNumArray startVals(env);
            for (int i = 0; i < m; ++i) {
                for (int j = 0; j < n; ++j) {
                    startVars.add(x[i][j]);
                    startVals.add(warm_start->alpha[i * n + j] > 0.5 ? 1.0 : 0.0);
                }
            }
            double warm_z = 0.0;
            for (int j = 0; j < n; ++j) {
                double v = warm_start->p_tilde[j];
                double lb = max(1.0, static_cast<double>(inst.p[j] - inst.delta[j]));
                double ub = static_cast<double>(inst.p[j]);
                v = min(ub, max(lb, v));
                if (ptype == PTILDE_DISCRETE) v = round(v);
                startVars.add(p_tilde[j]);
                startVals.add(v);
                warm_z = max(warm_z, static_cast<double>(inst.p[j]) - v);
            }
            if (ptype == PTILDE_DISCRETE) warm_z = ceil(warm_z - EPS);
            startVars.add(z);
            startVals.add(warm_z);
            try { cplex.addMIPStart(startVars, startVals); } catch (...) {}
            startVars.end();
            startVals.end();
        }

        bool ok = cplex.solve();
        IloAlgorithm::Status st = cplex.getStatus();
        res.status = cplexStatusToString(st);
        if (ok && (st == IloAlgorithm::Optimal || st == IloAlgorithm::Feasible)) {
            res.feasible = true;
            res.solved = true;
            res.optimal = (st == IloAlgorithm::Optimal);
            res.objective = cplex.getObjValue();
            try { res.best_bound = cplex.getBestObjValue(); } catch (...) {}
            try { res.gap = cplex.getMIPRelativeGap(); } catch (...) {}
            res.sol.alpha.assign(m * n, 0.0);
            res.sol.p_tilde.assign(n, 0.0);
            for (int i = 0; i < m; ++i) {
                for (int j = 0; j < n; ++j) {
                    res.sol.alpha[i * n + j] = cplex.getValue(x[i][j]) > 0.5 ? 1.0 : 0.0;
                }
            }
            for (int j = 0; j < n; ++j) res.sol.p_tilde[j] = cplex.getValue(p_tilde[j]);
            res.sol.objective = res.objective;
        }
    } catch (IloException& e) {
        cerr << "Direct max-compression MIP error: " << e << endl;
        res.status = "Error";
    }
    env.end();

    auto end = chrono::steady_clock::now();
    res.time_sec = chrono::duration<double>(end - start).count();
    if (res.time_sec >= time_limit_sec - 1.0) res.time_limit = true;
    return res;
}

// ----------------------------- Fixed-assignment max-compression optimizer -----------------------------

MethodResult optimizeMaxForFixedAssignment(const InstanceData& inst,
                                           PTildeType ptype,
                                           const vector<double>& alpha_values,
                                           double time_limit_sec = SUBPROBLEM_TIME_LIMIT_SEC) {
    MethodResult res;
    auto start = chrono::steady_clock::now();
    IloEnv env;
    try {
        IloModel model(env);
        int n = inst.n;
        int m = inst.m;
        IloNumVarArray p_tilde(env, n);
        for (int j = 0; j < n; ++j) {
            double lb = max(1.0, static_cast<double>(inst.p[j] - inst.delta[j]));
            double ub = static_cast<double>(inst.p[j]);
            p_tilde[j] = IloNumVar(env, lb, ub,
                                   (ptype == PTILDE_DISCRETE ? ILOINT : ILOFLOAT));
        }
        IloNumVar z(env, 0.0, IloInfinity,
                    (ptype == PTILDE_DISCRETE ? ILOINT : ILOFLOAT));
        model.add(IloMinimize(env, z));
        for (int j = 0; j < n; ++j) model.add(z >= static_cast<double>(inst.p[j]) - p_tilde[j]);

        for (int i = 0; i < m; ++i) {
            IloExpr load(env);
            for (int j = 0; j < n; ++j) {
                if (alpha_values[i * n + j] > 0.5) load += p_tilde[j];
            }
            model.add(load <= inst.C_star);
            load.end();
        }

        IloCplex solver(model);
        solver.setOut(env.getNullStream());
        solver.setParam(IloCplex::Param::Threads, 1);
        solver.setParam(IloCplex::Param::TimeLimit, time_limit_sec);
        solver.setParam(IloCplex::Param::MIP::Tolerances::MIPGap, 1e-6);

        bool ok = solver.solve();
        IloAlgorithm::Status st = solver.getStatus();
        res.status = cplexStatusToString(st);
        if (ok && (st == IloAlgorithm::Optimal || st == IloAlgorithm::Feasible)) {
            res.feasible = true;
            res.solved = true;
            res.optimal = (st == IloAlgorithm::Optimal);
            res.objective = solver.getObjValue();
            try { res.best_bound = solver.getBestObjValue(); } catch (...) {}
            try { res.gap = solver.getMIPRelativeGap(); } catch (...) {}
            res.sol.alpha = alpha_values;
            res.sol.p_tilde.assign(n, 0.0);
            for (int j = 0; j < n; ++j) res.sol.p_tilde[j] = solver.getValue(p_tilde[j]);
            res.sol.objective = res.objective;
        }
    } catch (IloException& e) {
        cerr << "Fixed-assignment max optimizer error: " << e << endl;
        res.status = "Error";
    }
    env.end();
    auto end = chrono::steady_clock::now();
    res.time_sec = chrono::duration<double>(end - start).count();
    if (res.time_sec >= time_limit_sec - 1.0) res.time_limit = true;
    return res;
}

// ----------------------------- BD_sum solver for total compression -----------------------------

class BDSumSolver {
private:
    const InstanceData& inst;
    IloEnv env;
    IloModel model;
    IloCplex cplex;
    IloNumVarArray alpha;
    IloNumVar eta;

public:
    BDSumSolver(const InstanceData& data)
        : inst(data), env(), model(env), cplex(model), alpha(env), eta() {
        initialize();
    }
    ~BDSumSolver() { env.end(); }
    MethodResult solve();

private:
    void initialize();
    bool extractAlpha(vector<double>& alpha_values);
    double totalCompressionValue(const vector<double>& alpha_values, vector<double>& p_tilde_values);
    void addCut(double Q, const vector<double>& alpha_bar);
};

void BDSumSolver::initialize() {
    int m = inst.m, n = inst.n;
    alpha = IloNumVarArray(env, m * n, 0, 1, ILOINT);
    eta = IloNumVar(env, 0.0, IloInfinity, ILOFLOAT);
    model.add(IloMinimize(env, eta));

    for (int j = 0; j < n; ++j) {
        IloExpr assign(env);
        for (int i = 0; i < m; ++i) assign += alpha[i * n + j];
        model.add(assign == 1);
        assign.end();
    }
    for (int i = 0; i < m; ++i) {
        IloExpr min_load(env);
        for (int j = 0; j < n; ++j) {
            min_load += alpha[i * n + j] * max(1, inst.p[j] - inst.delta[j]);
        }
        model.add(min_load <= inst.C_star);
        min_load.end();
    }
}

bool BDSumSolver::extractAlpha(vector<double>& alpha_values) {
    int m = inst.m, n = inst.n;
    alpha_values.assign(m * n, 0.0);
    for (int i = 0; i < m; ++i) {
        for (int j = 0; j < n; ++j) {
            alpha_values[i * n + j] = cplex.getValue(alpha[i * n + j]) > 0.5 ? 1.0 : 0.0;
        }
    }
    return true;
}

double BDSumSolver::totalCompressionValue(const vector<double>& alpha_values,
                                          vector<double>& p_tilde_values) {
    int m = inst.m, n = inst.n;
    vector<double> loads(m, 0.0);
    for (int i = 0; i < m; ++i) {
        for (int j = 0; j < n; ++j) {
            if (alpha_values[i * n + j] > 0.5) loads[i] += inst.p[j];
        }
    }
    double Q = 0.0;
    p_tilde_values.assign(n, 0.0);
    for (int j = 0; j < n; ++j) p_tilde_values[j] = inst.p[j];

    // Minimal total compression for a fixed assignment equals the sum of machine overloads.
    // We construct one feasible compression vector greedily for warm-starting later models.
    for (int i = 0; i < m; ++i) {
        double overload = max(0.0, loads[i] - static_cast<double>(inst.C_star));
        Q += overload;
        double remaining = overload;
        if (remaining <= EPS) continue;
        for (int j = 0; j < n && remaining > EPS; ++j) {
            if (alpha_values[i * n + j] > 0.5) {
                double cap = min(remaining, static_cast<double>(inst.delta[j]));
                p_tilde_values[j] -= cap;
                remaining -= cap;
            }
        }
    }
    return Q;
}

void BDSumSolver::addCut(double Q, const vector<double>& alpha_bar) {
    int m = inst.m, n = inst.n;
    IloExpr lhs(env);
    lhs += eta;
    double rhs = Q;
    for (int i = 0; i < m; ++i) {
        double original_load = 0.0;
        for (int j = 0; j < n; ++j) {
            if (alpha_bar[i * n + j] > 0.5) original_load += inst.p[j];
        }
        if (original_load > inst.C_star + EPS) {
            for (int j = 0; j < n; ++j) {
                double coeff = static_cast<double>(inst.p[j]);
                lhs -= coeff * alpha[i * n + j];
                rhs -= coeff * alpha_bar[i * n + j];
            }
        }
    }
    model.add(lhs >= rhs);
    lhs.end();
}

MethodResult BDSumSolver::solve() {
    MethodResult res;
    auto start = chrono::steady_clock::now();
    try {
        cplex.setOut(env.getNullStream());
        cplex.setParam(IloCplex::Param::Threads, 1);
        cplex.setParam(IloCplex::Param::TimeLimit, MASTER_TIME_LIMIT_SEC);
        cplex.setParam(IloCplex::Param::MIP::Tolerances::MIPGap, 1e-6);

        double UB = 1e100;
        double LB = 0.0;
        int no_improve = 0;
        vector<double> alpha_bar, p_tilde_bar;

        for (int iter = 1; iter <= MAX_BD_ITERATIONS; ++iter) {
            bool ok = cplex.solve();
            IloAlgorithm::Status st = cplex.getStatus();
            if (!ok || !(st == IloAlgorithm::Optimal || st == IloAlgorithm::Feasible)) {
                res.status = string("Master_") + cplexStatusToString(st);
                break;
            }
            LB = cplex.getObjValue();
            extractAlpha(alpha_bar);
            double Q = totalCompressionValue(alpha_bar, p_tilde_bar);
            if (Q < UB - EPS) {
                UB = Q;
                no_improve = 0;
                res.sol.alpha = alpha_bar;
                res.sol.p_tilde = p_tilde_bar;
                res.sol.objective = Q;
            } else {
                no_improve++;
            }
            addCut(Q, alpha_bar);
            double gap = (UB - LB) / max(1.0, fabs(UB));
            if (UB < 1e90 && gap <= 1e-6) {
                res.feasible = true;
                res.solved = true;
                res.optimal = true;
                res.status = "Optimal";
                res.objective = UB;
                res.best_bound = LB;
                res.gap = 0.0;
                res.iterations = iter;
                break;
            }
            if (no_improve >= MAX_NO_IMPROVE_ITERATIONS && UB < 1e90) {
                res.feasible = true;
                res.solved = true;
                res.optimal = false;
                res.status = "NoImproveStop";
                res.objective = UB;
                res.best_bound = LB;
                res.gap = gap;
                res.iterations = iter;
                break;
            }
            if (iter == MAX_BD_ITERATIONS && UB < 1e90) {
                res.feasible = true;
                res.solved = true;
                res.optimal = false;
                res.status = "MaxIterations";
                res.objective = UB;
                res.best_bound = LB;
                res.gap = gap;
                res.iterations = iter;
            }
        }
    } catch (IloException& e) {
        cerr << "BD_sum error: " << e << endl;
        res.status = "Error";
    }
    auto end = chrono::steady_clock::now();
    res.time_sec = chrono::duration<double>(end - start).count();
    if (res.time_sec >= MASTER_TIME_LIMIT_SEC - 1.0) res.time_limit = true;
    return res;
}

// ----------------------------- H_max heuristic -----------------------------

double effectiveMinPForZ(const InstanceData& inst, int j, double z, PTildeType ptype) {
    double base_lb = max(1.0, static_cast<double>(inst.p[j] - inst.delta[j]));
    double z_eff = z;
    if (ptype == PTILDE_DISCRETE) z_eff = floor(z + EPS);
    double lb = max(base_lb, static_cast<double>(inst.p[j]) - z_eff);
    if (ptype == PTILDE_DISCRETE) lb = ceil(lb - EPS);
    return lb;
}

bool greedyFeasibleForZ(const InstanceData& inst, double z, PTildeType ptype,
                        int random_seed, vector<double>& alpha_out, vector<double>& ptilde_out) {
    int n = inst.n, m = inst.m;
    vector<pair<double,int> > jobs;
    for (int j = 0; j < n; ++j) jobs.push_back(make_pair(effectiveMinPForZ(inst, j, z, ptype), j));
    if (random_seed >= 0) {
        mt19937 rng(static_cast<unsigned int>(random_seed));
        shuffle(jobs.begin(), jobs.end(), rng);
        stable_sort(jobs.begin(), jobs.end(), [](const pair<double,int>& a, const pair<double,int>& b) {
            return a.first > b.first;
        });
    } else {
        sort(jobs.begin(), jobs.end(), [](const pair<double,int>& a, const pair<double,int>& b) {
            return a.first > b.first;
        });
    }

    vector<double> loads(m, 0.0);
    vector<int> assignment(n, -1);
    for (size_t idx = 0; idx < jobs.size(); ++idx) {
        int j = jobs[idx].second;
        double req = jobs[idx].first;
        int best_i = -1;
        double best_remaining = 1e100;
        for (int i = 0; i < m; ++i) {
            double rem = static_cast<double>(inst.C_star) - (loads[i] + req);
            if (rem >= -EPS && rem < best_remaining) {
                best_remaining = rem;
                best_i = i;
            }
        }
        if (best_i < 0) return false;
        assignment[j] = best_i;
        loads[best_i] += req;
    }

    alpha_out.assign(m * n, 0.0);
    ptilde_out.assign(n, 0.0);
    for (int j = 0; j < n; ++j) {
        if (assignment[j] < 0) return false;
        alpha_out[assignment[j] * n + j] = 1.0;
        ptilde_out[j] = effectiveMinPForZ(inst, j, z, ptype);
    }
    return checkSolutionFeasibility(inst, alpha_out, ptilde_out, ptype);
}

MethodResult solveHMaxHeuristic(const InstanceData& inst, PTildeType ptype) {
    MethodResult res;
    auto start = chrono::steady_clock::now();

    double low = 0.0;
    double high = 0.0;
    for (int j = 0; j < inst.n; ++j) high = max(high, static_cast<double>(inst.delta[j]));

    vector<double> best_alpha, best_ptilde;
    bool found = false;

    if (ptype == PTILDE_DISCRETE) {
        int L = 0, H = static_cast<int>(ceil(high));
        while (L <= H) {
            int mid = (L + H) / 2;
            bool ok = false;
            vector<double> a, pt;
            for (int trial = -1; trial < 20 && !ok; ++trial) {
                ok = greedyFeasibleForZ(inst, mid, ptype, trial < 0 ? -1 : inst.seed + 97 * trial, a, pt);
            }
            if (ok) {
                found = true;
                best_alpha = a;
                best_ptilde = pt;
                H = mid - 1;
            } else {
                L = mid + 1;
            }
        }
    } else {
        for (int it = 0; it < 45; ++it) {
            double mid = (low + high) / 2.0;
            bool ok = false;
            vector<double> a, pt;
            for (int trial = -1; trial < 20 && !ok; ++trial) {
                ok = greedyFeasibleForZ(inst, mid, ptype, trial < 0 ? -1 : inst.seed + 97 * trial + it, a, pt);
            }
            if (ok) {
                found = true;
                high = mid;
                best_alpha = a;
                best_ptilde = pt;
            } else {
                low = mid;
            }
        }
    }

    if (found) {
        MethodResult fixed = optimizeMaxForFixedAssignment(inst, ptype, best_alpha, 30.0);
        if (fixed.solved) {
            res = fixed;
            res.status = string("Hmax+") + fixed.status;
        } else {
            double max_dev = 0.0;
            checkSolutionFeasibility(inst, best_alpha, best_ptilde, ptype, &max_dev, NULL);
            res.feasible = true;
            res.solved = true;
            res.optimal = false;
            res.status = "HmaxFeasible";
            res.objective = max_dev;
            res.sol.alpha = best_alpha;
            res.sol.p_tilde = best_ptilde;
            res.sol.objective = max_dev;
        }
    } else {
        res.status = "HmaxFailed";
    }

    auto end = chrono::steady_clock::now();
    res.time_sec = chrono::duration<double>(end - start).count();
    return res;
}

// ----------------------------- BD_max heuristic / BD-based assignment search -----------------------------

MethodResult solveBDMaxHeuristic(const InstanceData& inst, PTildeType ptype) {
    MethodResult res;
    auto start = chrono::steady_clock::now();

    // Use BD_sum to obtain a compression-aware assignment, then optimize max compression
    // on that fixed assignment. This is a BD-based upper-bound method used as BD_max.
    BDSumSolver bd_sum(inst);
    MethodResult total = bd_sum.solve();
    if (total.solved && !total.sol.alpha.empty()) {
        MethodResult fixed = optimizeMaxForFixedAssignment(inst, ptype, total.sol.alpha, SUBPROBLEM_TIME_LIMIT_SEC);
        if (fixed.solved) {
            res = fixed;
            res.status = string("BDmaxFixed+") + fixed.status;
        }
    }

    // If BD_sum assignment fails, fall back to Hmax assignment.
    if (!res.solved) {
        MethodResult h = solveHMaxHeuristic(inst, ptype);
        if (h.solved) {
            res = h;
            res.status = "BDmaxFallbackHmax";
        } else {
            res.status = "BDmaxFailed";
        }
    }

    auto end = chrono::steady_clock::now();
    res.time_sec = chrono::duration<double>(end - start).count();
    res.optimal = false;
    return res;
}

// ----------------------------- Matheuristic -----------------------------

MethodResult solveMatheuristic(const InstanceData& inst, PTildeType ptype) {
    MethodResult res;
    auto start = chrono::steady_clock::now();

    // Phase 1: BD_sum lower bound S*/n.
    BDSumSolver bd_sum(inst);
    MethodResult total = bd_sum.solve();
    double LB = 0.0;
    if (total.solved) {
        LB = total.objective / static_cast<double>(inst.n);
        if (ptype == PTILDE_DISCRETE) LB = ceil(LB - EPS);
    }

    // Phase 2: best warm-start solution from Hmax and BDmax.
    MethodResult h = solveHMaxHeuristic(inst, ptype);
    MethodResult bd = solveBDMaxHeuristic(inst, ptype);
    MethodResult warm;
    if (h.solved && bd.solved) warm = (h.objective <= bd.objective + EPS ? h : bd);
    else if (h.solved) warm = h;
    else if (bd.solved) warm = bd;

    if (!warm.solved) {
        // Last resort: solve direct MIP.
        res = solveMaxCompressionMIP(inst, ptype, MATHEURISTIC_MIP_TIME_LIMIT_SEC, NULL, LB,
                                     numeric_limits<double>::quiet_NaN());
        res.status = string("MatheuristicNoWarm+") + res.status;
        auto end = chrono::steady_clock::now();
        res.time_sec = chrono::duration<double>(end - start).count();
        return res;
    }

    double UB = warm.objective;
    double mean_bound = (LB + UB) / 2.0;
    if (ptype == PTILDE_DISCRETE) mean_bound = floor(mean_bound + EPS);

    MethodResult best = warm;
    best.optimal = false;

    // Phase 3.1: try lower half [LB, mean_bound].
    MethodResult mip1;
    if (mean_bound + EPS >= LB && mean_bound <= UB + EPS) {
        mip1 = solveMaxCompressionMIP(inst, ptype, MATHEURISTIC_MIP_TIME_LIMIT_SEC,
                                      &warm.sol, LB, mean_bound);
        if (mip1.solved && mip1.objective < best.objective - EPS) best = mip1;
    }

    // Phase 3.2: if no feasible improvement in lower half, solve upper half [mean_bound, UB].
    if (!mip1.solved || mip1.objective > mean_bound + EPS) {
        double lb2 = mean_bound;
        if (ptype == PTILDE_DISCRETE) lb2 = max(LB, mean_bound);
        MethodResult mip2 = solveMaxCompressionMIP(inst, ptype, MATHEURISTIC_MIP_TIME_LIMIT_SEC,
                                                   &warm.sol, lb2, UB);
        if (mip2.solved && mip2.objective < best.objective - EPS) best = mip2;
        if (!best.solved && mip2.solved) best = mip2;
    }

    res = best;
    res.status = string("Matheuristic+") + best.status;
    res.best_bound = LB;
    if (res.solved) res.gap = max(0.0, (res.objective - LB) / max(1.0, fabs(res.objective)));

    auto end = chrono::steady_clock::now();
    res.time_sec = chrono::duration<double>(end - start).count();
    return res;
}

// ----------------------------- Output functions -----------------------------

void writeDetailedCsvHeader(ofstream& file) {
    file << "pt_class,ptype,target_rho,actual_rho,n,m,run_id,seed,C_star_raw,C_star_used,C_star_adjusted,min_possible_makespan,sum_p,sum_delta,sum_min_p,"
         << "h_status,h_obj,h_time,h_gap,"
         << "bd_status,bd_obj,bd_time,bd_gap,"
         << "math_status,math_obj,math_time,math_gap,math_bound,"
         << "mip_status,mip_optimal,mip_obj,mip_time,mip_gap,mip_bound,mip_time_limit\n";
}

void appendDetailedCsvRow(ofstream& file, const RunResult& r) {
    const InstanceData& inst = r.inst;
    file << inst.pt_class << "," << typeName(r.ptype) << ","
         << fixed << setprecision(6) << inst.target_rho << "," << inst.actual_rho << ","
         << inst.n << "," << inst.m << "," << inst.run_id << "," << inst.seed << ","
         << inst.cstar_raw << "," << inst.C_star << "," << (inst.cstar_adjusted ? 1 : 0) << ","
         << inst.min_possible_makespan << "," << inst.sum_p << "," << inst.sum_delta << "," << inst.sum_min_p << ","
         << r.hmax.status << "," << doubleToCsv(r.hmax.objective) << "," << doubleToCsv(r.hmax.time_sec) << "," << doubleToCsv(r.hmax.gap) << ","
         << r.bdmax.status << "," << doubleToCsv(r.bdmax.objective) << "," << doubleToCsv(r.bdmax.time_sec) << "," << doubleToCsv(r.bdmax.gap) << ","
         << r.matheuristic.status << "," << doubleToCsv(r.matheuristic.objective) << "," << doubleToCsv(r.matheuristic.time_sec) << "," << doubleToCsv(r.matheuristic.gap) << "," << doubleToCsv(r.matheuristic.best_bound) << ","
         << r.mip.status << "," << (r.mip.optimal ? 1 : 0) << "," << doubleToCsv(r.mip.objective) << "," << doubleToCsv(r.mip.time_sec) << "," << doubleToCsv(r.mip.gap) << "," << doubleToCsv(r.mip.best_bound) << "," << (r.mip.time_limit ? 1 : 0) << "\n";
}

void writeSummaryCsv(const vector<RunResult>& runs, const string& filename) {
    ofstream file(filename.c_str());
    if (!file.is_open()) {
        cerr << "Could not write summary CSV: " << filename << endl;
        return;
    }

    file << "pt_class,ptype,target_rho,n,m,runs,adjusted_Cstar_count,mean_actual_rho,"
         << "h_mean_obj,h_mean_time,"
         << "bd_mean_obj,bd_mean_time,"
         << "math_mean_obj,math_mean_time,math_mean_gap,"
         << "mip_feasible_count,mip_optimal_count,mip_time_limit_count,mip_mean_obj,mip_mean_time,mip_mean_gap\n";

    vector<string> pt_classes;
    pt_classes.push_back("PT-N");
    pt_classes.push_back("PT-W");

    vector<PTildeType> types;
    types.push_back(PTILDE_CONTINUOUS);
    types.push_back(PTILDE_DISCRETE);

    vector<double> load_levels;
    load_levels.push_back(1.05);
    load_levels.push_back(1.15);
    load_levels.push_back(1.25);

    vector<pair<int,int> > configs;
    configs.push_back(make_pair(20, 2));
    configs.push_back(make_pair(20, 3));
    configs.push_back(make_pair(20, 5));
    configs.push_back(make_pair(30, 2));
    configs.push_back(make_pair(30, 3));
    configs.push_back(make_pair(30, 5));
    configs.push_back(make_pair(30, 10));
    configs.push_back(make_pair(50, 2));
    configs.push_back(make_pair(50, 3));
    configs.push_back(make_pair(50, 5));
    configs.push_back(make_pair(50, 10));
    configs.push_back(make_pair(100, 2));
    configs.push_back(make_pair(100, 3));
    configs.push_back(make_pair(100, 5));
    configs.push_back(make_pair(100, 10));
    configs.push_back(make_pair(200, 2));
    configs.push_back(make_pair(200, 3));
    configs.push_back(make_pair(200, 5));
    configs.push_back(make_pair(200, 10));

    for (size_t pc = 0; pc < pt_classes.size(); ++pc) {
        string pt = pt_classes[pc];
        for (size_t tt = 0; tt < types.size(); ++tt) {
            for (size_t ll = 0; ll < load_levels.size(); ++ll) {
                double rho = load_levels[ll];
                for (size_t cc = 0; cc < configs.size(); ++cc) {
                    PTildeType type = types[tt];
                    int n = configs[cc].first;
                    int m = configs[cc].second;
                    int count = 0, adjusted_count = 0, mip_feas = 0, mip_opt = 0, mip_tl = 0;
                    vector<double> actual_rhos;
                    vector<double> h_obj, h_time, bd_obj, bd_time, math_obj, math_time, math_gap;
                    vector<double> mip_obj, mip_time, mip_gap;
                    for (size_t r = 0; r < runs.size(); ++r) {
                        if (runs[r].inst.pt_class == pt && runs[r].ptype == type &&
                            fabs(runs[r].inst.target_rho - rho) < 1e-9 &&
                            runs[r].inst.n == n && runs[r].inst.m == m) {
                            count++;
                            if (runs[r].inst.cstar_adjusted) adjusted_count++;
                            actual_rhos.push_back(runs[r].inst.actual_rho);
                            if (runs[r].hmax.solved) { h_obj.push_back(runs[r].hmax.objective); h_time.push_back(runs[r].hmax.time_sec); }
                            if (runs[r].bdmax.solved) { bd_obj.push_back(runs[r].bdmax.objective); bd_time.push_back(runs[r].bdmax.time_sec); }
                            if (runs[r].matheuristic.solved) {
                                math_obj.push_back(runs[r].matheuristic.objective);
                                math_time.push_back(runs[r].matheuristic.time_sec);
                                if (!std::isnan(runs[r].matheuristic.gap)) math_gap.push_back(runs[r].matheuristic.gap);
                            }
                            if (runs[r].mip.feasible) mip_feas++;
                            if (runs[r].mip.optimal) mip_opt++;
                            if (runs[r].mip.time_limit) mip_tl++;
                            if (runs[r].mip.solved) {
                                mip_obj.push_back(runs[r].mip.objective);
                                mip_time.push_back(runs[r].mip.time_sec);
                                if (!std::isnan(runs[r].mip.gap)) mip_gap.push_back(runs[r].mip.gap);
                            }
                        }
                    }
                    file << pt << "," << typeName(type) << "," << fixed << setprecision(6) << rho << ","
                         << n << "," << m << "," << count << "," << adjusted_count << ","
                         << doubleToCsv(meanValue(actual_rhos)) << ","
                         << doubleToCsv(meanValue(h_obj)) << "," << doubleToCsv(meanValue(h_time)) << ","
                         << doubleToCsv(meanValue(bd_obj)) << "," << doubleToCsv(meanValue(bd_time)) << ","
                         << doubleToCsv(meanValue(math_obj)) << "," << doubleToCsv(meanValue(math_time)) << "," << doubleToCsv(meanValue(math_gap)) << ","
                         << mip_feas << "," << mip_opt << "," << mip_tl << ","
                         << doubleToCsv(meanValue(mip_obj)) << "," << doubleToCsv(meanValue(mip_time)) << "," << doubleToCsv(meanValue(mip_gap)) << "\n";
                }
            }
        }
    }
    file.close();
}

void writeLatexTableSkeleton(const vector<RunResult>& runs, const string& filename, const string& pt_class, PTildeType type, double rho) {
    ofstream file(filename.c_str());
    if (!file.is_open()) return;
    file << "% Auto-generated table skeleton. Values are averages over 10 instances.\n";
    file << "\\begin{table}[htbp]\n\\centering\n\\footnotesize\n";
    file << "\\caption{Average computational results for the maximum compression problem with " << typeName(type) << " $\\tilde p_j$ and $\\rho=" << fixed << setprecision(2) << rho << "$.}\n";
    file << "\\begin{tabular}{lrrrrrrrr}\n\\toprule\n";
    file << "Config & H$_{\\max}$ Obj & BD$_{\\max}$ Obj & Math Obj & Math Time & MIP Obj & MIP Time & MIP Gap & MIP Opt \\\\\n\\midrule\n";

    vector<pair<int,int> > configs;
    configs.push_back(make_pair(20, 2)); configs.push_back(make_pair(20, 3)); configs.push_back(make_pair(20, 5));
    configs.push_back(make_pair(30, 2)); configs.push_back(make_pair(30, 3)); configs.push_back(make_pair(30, 5)); configs.push_back(make_pair(30, 10));
    configs.push_back(make_pair(50, 2)); configs.push_back(make_pair(50, 3)); configs.push_back(make_pair(50, 5)); configs.push_back(make_pair(50, 10));
    configs.push_back(make_pair(100, 2)); configs.push_back(make_pair(100, 3)); configs.push_back(make_pair(100, 5)); configs.push_back(make_pair(100, 10));
    configs.push_back(make_pair(200, 2)); configs.push_back(make_pair(200, 3)); configs.push_back(make_pair(200, 5)); configs.push_back(make_pair(200, 10));

    for (size_t cc = 0; cc < configs.size(); ++cc) {
        int n = configs[cc].first, m = configs[cc].second;
        vector<double> h_obj, bd_obj, math_obj, math_time, mip_obj, mip_time, mip_gap;
        int mip_opt = 0, num = 0;
        for (size_t r = 0; r < runs.size(); ++r) {
            if (runs[r].inst.pt_class == pt_class && runs[r].ptype == type && fabs(runs[r].inst.target_rho - rho) < 1e-9 && runs[r].inst.n == n && runs[r].inst.m == m) {
                num++;
                if (runs[r].hmax.solved) h_obj.push_back(runs[r].hmax.objective);
                if (runs[r].bdmax.solved) bd_obj.push_back(runs[r].bdmax.objective);
                if (runs[r].matheuristic.solved) { math_obj.push_back(runs[r].matheuristic.objective); math_time.push_back(runs[r].matheuristic.time_sec); }
                if (runs[r].mip.solved) { mip_obj.push_back(runs[r].mip.objective); mip_time.push_back(runs[r].mip.time_sec); if (!std::isnan(runs[r].mip.gap)) mip_gap.push_back(100.0 * runs[r].mip.gap); }
                if (runs[r].mip.optimal) mip_opt++;
            }
        }
        file << "n" << n << " m" << m << " & "
             << fixed << setprecision(2) << meanValue(h_obj) << " & "
             << meanValue(bd_obj) << " & "
             << meanValue(math_obj) << " & "
             << meanValue(math_time) << " & "
             << meanValue(mip_obj) << " & "
             << meanValue(mip_time) << " & "
             << meanValue(mip_gap) << " & "
             << mip_opt << "/" << num << " \\\\\n";
    }
    file << "\\bottomrule\n\\end{tabular}\n\\end{table}\n";
    file.close();
}

// ----------------------------- Experiment runner -----------------------------

RunResult runOne(const InstanceData& inst, PTildeType type) {
    RunResult r;
    r.inst = inst;
    r.ptype = type;

    r.hmax = solveHMaxHeuristic(inst, type);
    r.bdmax = solveBDMaxHeuristic(inst, type);
    r.matheuristic = solveMatheuristic(inst, type);
    r.mip = solveMaxCompressionMIP(inst, type, DIRECT_MIP_TIME_LIMIT_SEC, NULL,
                                   numeric_limits<double>::quiet_NaN(),
                                   numeric_limits<double>::quiet_NaN());
    return r;
}

int main() {
    string timestamp = getCurrentTimestamp();
    string base_dir = OUTPUT_ROOT + "/maximum_compression_sensitivity_experiment_" + timestamp;
    string instance_dir = base_dir + "/instances";
    makeDirectory(base_dir);
    makeDirectory(instance_dir);

    string detailed_csv = base_dir + "/maxcompression_sensitivity_detailed_" + timestamp + ".csv";
    string summary_csv  = base_dir + "/maxcompression_sensitivity_summary_" + timestamp + ".csv";
    string readme_file  = base_dir + "/README_" + timestamp + ".txt";

    vector<string> pt_classes;
    pt_classes.push_back("PT-N");
    pt_classes.push_back("PT-W");

    vector<double> load_levels;
  //  load_levels.push_back(1.05);
  //  load_levels.push_back(1.15);
    load_levels.push_back(1.25);

    vector<pair<int,int> > configs;
    configs.push_back(make_pair(20, 2));
    configs.push_back(make_pair(20, 3));
    configs.push_back(make_pair(20, 5));
    configs.push_back(make_pair(30, 2));
    configs.push_back(make_pair(30, 3));
    configs.push_back(make_pair(30, 5));
    configs.push_back(make_pair(30, 10));
    configs.push_back(make_pair(50, 2));
    configs.push_back(make_pair(50, 3));
    configs.push_back(make_pair(50, 5));
    configs.push_back(make_pair(50, 10));
    configs.push_back(make_pair(100, 2));
    configs.push_back(make_pair(100, 3));
    configs.push_back(make_pair(100, 5));
    configs.push_back(make_pair(100, 10));
    configs.push_back(make_pair(200, 2));
    configs.push_back(make_pair(200, 3));
    configs.push_back(make_pair(200, 5));
    configs.push_back(make_pair(200, 10));

    ofstream readme(readme_file.c_str());
    if (readme.is_open()) {
        readme << "Maximum-compression sensitivity experiment with continuous/discrete p_tilde_j\n";
        readme << "Timestamp: " << timestamp << "\n";
        readme << "Output directory: " << base_dir << "\n\n";
        readme << "Instance generation: identical to the total-compression sensitivity experiment\n";
        readme << "  PT-N: p_j ~ discrete U[10,24], delta_j ~ discrete U[1,5]\n";
        readme << "  PT-W: p_j ~ discrete U[1,100], delta_j = min{p_j-1, ceil(r_j p_j)}, r_j ~ U[0.10,0.30]\n";
        readme << "  rho in {1.05, 1.15, 1.25}, rho = sum_j p_j/(m C*)\n";
        readme << "  C*(rho) = ceil(sum_j p_j/(m rho)); adjusted to min feasible C* if needed\n";
        readme << "  10 instances per pt-class/n-m-rho configuration\n\n";
        readme << "Variants:\n";
        readme << "  continuous: p_tilde_j continuous\n";
        readme << "  discrete:   p_tilde_j integer\n\n";
        readme << "Compared methods:\n";
        readme << "  H_max heuristic\n";
        readme << "  BD_max heuristic / BD-based assignment search\n";
        readme << "  Matheuristic: BD_sum lower bound + warm-started bounded MIP\n";
        readme << "  Direct MIP\n\n";
        readme << "Time limits:\n";
        readme << "  Direct MIP: " << DIRECT_MIP_TIME_LIMIT_SEC << " seconds\n";
        readme << "  BD_sum master: " << MASTER_TIME_LIMIT_SEC << " seconds\n";
        readme << "  Fixed-assignment subproblem: " << SUBPROBLEM_TIME_LIMIT_SEC << " seconds\n";
        readme.close();
    }

    ofstream detailed(detailed_csv.c_str());
    if (!detailed.is_open()) {
        cerr << "Could not open detailed CSV for writing: " << detailed_csv << endl;
        return 1;
    }
    writeDetailedCsvHeader(detailed);

    vector<RunResult> all_runs;
    int total_runs = static_cast<int>(pt_classes.size() * load_levels.size() * configs.size() * NUM_RUNS_PER_CONFIGURATION * 2);
    int done = 0;

    cout << "=== MAXIMUM-COMPRESSION SENSITIVITY EXPERIMENT ===" << endl;
    cout << "Output directory: " << base_dir << endl;
    cout << "Total runs (including PT-N/PT-W and continuous/discrete): " << total_runs << endl;

    for (size_t pc = 0; pc < pt_classes.size(); ++pc) {
        string pt = pt_classes[pc];
        for (size_t ll = 0; ll < load_levels.size(); ++ll) {
            double rho = load_levels[ll];
            for (size_t cc = 0; cc < configs.size(); ++cc) {
                int n = configs[cc].first;
                int m = configs[cc].second;
                cout << "\n--- Configuration " << pt << ", rho=" << fixed << setprecision(2) << rho
                     << ", n=" << n << ", m=" << m << " ---" << endl;
                for (int run_id = 1; run_id <= NUM_RUNS_PER_CONFIGURATION; ++run_id) {
                    InstanceData inst = generateInstance(n, m, pt, run_id, rho);
                    string inst_file = instance_dir + "/instance_" + pt + "_rho" + sanitizeRho(rho) +
                                       "_n" + to_string(n) + "_m" + to_string(m) +
                                       "_run" + to_string(run_id) + ".csv";
                    saveInstanceData(inst, inst_file);

                    for (int t = 0; t < 2; ++t) {
                        PTildeType type = (t == 0 ? PTILDE_CONTINUOUS : PTILDE_DISCRETE);
                        RunResult r = runOne(inst, type);
                        all_runs.push_back(r);
                        appendDetailedCsvRow(detailed, r);
                        detailed.flush();
                        done++;
                        cout << "Run " << setw(4) << done << "/" << total_runs
                             << " | " << pt
                             << " | rho=" << fixed << setprecision(2) << rho
                             << " | " << typeName(type)
                             << " | n" << n << "m" << m << " run" << run_id
                             << " | C*=" << inst.C_star << (inst.cstar_adjusted ? "(adj)" : "")
                             << " | actual_rho=" << setprecision(4) << inst.actual_rho
                             << " | H=" << r.hmax.status << ", obj=" << r.hmax.objective
                             << " | BD=" << r.bdmax.status << ", obj=" << r.bdmax.objective
                             << " | Math=" << r.matheuristic.status << ", obj=" << r.matheuristic.objective
                             << " | MIP=" << r.mip.status << ", obj=" << r.mip.objective
                             << ", gap=" << r.mip.gap
                             << ", time=" << r.mip.time_sec << endl;
                    }
                }
            }
        }
    }
    detailed.close();

    writeSummaryCsv(all_runs, summary_csv);
    for (size_t pc = 0; pc < pt_classes.size(); ++pc) {
        string pt = pt_classes[pc];
        for (size_t ll = 0; ll < load_levels.size(); ++ll) {
            double rho = load_levels[ll];
            writeLatexTableSkeleton(all_runs, base_dir + "/table_maxcompression_" + pt + "_continuous_rho" + sanitizeRho(rho) + "_" + timestamp + ".tex", pt, PTILDE_CONTINUOUS, rho);
            writeLatexTableSkeleton(all_runs, base_dir + "/table_maxcompression_" + pt + "_discrete_rho" + sanitizeRho(rho) + "_" + timestamp + ".tex", pt, PTILDE_DISCRETE, rho);
        }
    }

    cout << "\n=== EXPERIMENT COMPLETED ===" << endl;
    cout << "Detailed CSV: " << detailed_csv << endl;
    cout << "Summary CSV:  " << summary_csv << endl;
    cout << "Instance data: " << instance_dir << endl;
    return 0;
}
